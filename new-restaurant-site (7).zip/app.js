(function () {
  "use strict";
  var C = window.SITE, $ = function (s, r) { return (r || document).querySelector(s); };
  var money = function (v) { return Number(v).toFixed(2) + " " + C.currency; };
  var get = function (p) { return p.split(".").reduce(function (o, k) { return o && o[k]; }, C); };
  var el = function (t, c, h) { var e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
  var ph = function (t) { return '<span class="ph">' + t + "</span>"; };
  var priceHTML = function (v) { return v == null ? ph(C.priceNote) : '<span class="price">' + money(v) + "</span>"; };

  /* ---------- contenu depuis config.js ---------- */
  document.querySelectorAll("[data-cfg]").forEach(function (n) {
    var v = get(n.dataset.cfg); n.textContent = v; if (/^\[/.test(v)) n.innerHTML = ph(v.replace(/</g, "&lt;"));
  });
  var tabs = $("#catTabs"), box = $("#catPanels"), cur = -1, btns = [], panels = [];
  var hl = function (s) { return s.replace(/\[[^\]]+\]/g, function (m) { return ph(m); }); };
  var mq0 = window.matchMedia("(prefers-reduced-motion: reduce)");
  function panelHTML(c) {
    var h = "<h3>" + c.name + "</h3>" + (c.notes || []).map(function (n) { return '<p class="note">' + hl(n) + "</p>"; }).join("") + '<div class="groups">';
    c.groups.forEach(function (g) {
      h += "<div><h4>" + g.title + "</h4>" + g.items.map(function (d) {
        return '<div class="dish"><span><b>' + d[0] + "</b>" + (d[2] ? "<small>" + d[2] + "</small>" : "") + "</span>" + priceHTML(d[1]) + "</div>";
      }).join("") + "</div>";
    });
    return h + "</div>";
  }
  function select(i, user) {
    if (i === cur) return; cur = i;
    btns.forEach(function (b, k) { b.setAttribute("aria-selected", k === i); b.tabIndex = k === i ? 0 : -1; });
    panels.forEach(function (p, k) { p.hidden = k !== i; });
    var p = panels[i]; p.classList.remove("in"); void p.offsetWidth; p.classList.add("in");
    var b = btns[i]; tabs.scrollTo({ left: b.offsetLeft - (tabs.clientWidth - b.offsetWidth) / 2, behavior: "smooth" });
    if (user && innerWidth < 900) { var r = p.getBoundingClientRect(); if (r.top > innerHeight * 0.6 || r.top < 0) p.scrollIntoView({ behavior: mq0.matches ? "auto" : "smooth", block: "start" }); }
  }
  C.menu.forEach(function (c, i) {
    var p = el("div", "panel", panelHTML(c)); p.id = "menu-" + c.id; p.setAttribute("role", "tabpanel"); p.setAttribute("aria-labelledby", "tab-" + c.id); p.tabIndex = 0; p.hidden = true; box.appendChild(p); panels.push(p);
    var b = el("button", "cat" + (c.featured ? " big" : ""), '<img src="' + c.img + '" alt="' + c.alt + '" loading="lazy"><span>' + c.name + "</span>");
    b.type = "button"; b.id = "tab-" + c.id; b.setAttribute("role", "tab"); b.setAttribute("aria-controls", "menu-" + c.id);
    b.onclick = function () { select(i, true); };
    b.onkeydown = function (e) { var d = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0; if (d) { e.preventDefault(); var n = (i + d + btns.length) % btns.length; select(n); btns[n].focus(); } };
    btns.push(b); tabs.appendChild(b);
  });
  select(0);
  var fig = $("#shopFig");
  fig.innerHTML = C.shopPhoto ? '<img class="shopph" src="' + C.shopPhoto + '" alt="' + C.shopPhotoAlt + '">' :
    '<div class="shopph" role="img" aria-label="Espace réservé pour une photo de l\'intérieur"><p>' + ph("[Photo de l'intérieur à ajouter : comptoir, broche, ambiance chaude]") + "</p></div>";
  var V = C.visit, phone = $("#phone");
  phone.innerHTML = $("#fphone").innerHTML = V.phoneHref ? '<a href="' + V.phoneHref + '">' + V.phone + "</a>" : ph(V.phone);
  $("#fig").href = V.instagram;
  [["#dirBtn", V.directionsUrl], ["#callBtn", V.phoneHref]].forEach(function (x) {
    var a = $(x[0]);
    if (x[1]) { a.href = x[1]; if (/^http/.test(x[1])) { a.target = "_blank"; a.rel = "noopener"; } }
    else { a.setAttribute("aria-disabled", "true"); a.setAttribute("role", "link"); a.title = "Lien à ajouter dans config.js"; }
  });
  if (V.orderUrl) { var ob = el("a", "btn", "Commander"); ob.href = V.orderUrl; ob.target = "_blank"; ob.rel = "noopener"; $("#callBtn").parentNode.insertBefore(ob, $("#callBtn")); }
  $("#igBtn").href = V.instagram;
  var mb = $("#mapBox"), pi = $("#planImg"); pi.src = V.mapImage; pi.alt = V.mapAlt;
  function loadMap() {
    if (!V.mapEmbed || mb.classList.contains("live")) return;
    var f = document.createElement("iframe"); f.src = V.mapEmbed; f.title = "Carte Google Maps : " + V.street; f.loading = "lazy"; f.referrerPolicy = "no-referrer-when-downgrade";
    mb.appendChild(f); mb.classList.add("live");
  }
  if (!V.mapEmbed) $(".mapcta").hidden = true; else $("#mapLoad").onclick = loadMap;
  if (V.mapAutoLoad) loadMap();

  /* ---------- SEO : données structurées Schema.org générées depuis config.js ---------- */
  (function () {
    var S = C.site, V = C.visit, d = { "@context": "https://schema.org", "@type": "Restaurant", name: C.name, description: S.description, servesCuisine: S.cuisine,
      address: { "@type": "PostalAddress", streetAddress: V.street, postalCode: S.postalCode, addressLocality: S.locality, addressCountry: S.country },
      geo: { "@type": "GeoCoordinates", latitude: S.lat, longitude: S.lng },
      openingHoursSpecification: [{ "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], opens: V.opens, closes: V.closes }],
      sameAs: [V.instagram] };
    if (V.directionsUrl) d.hasMap = V.directionsUrl;
    if (S.url) { d.url = S.url; d.image = S.url + "assets/og-image.jpg"; }
    if (V.phoneHref) d.telephone = V.phoneHref.replace("tel:", "");
    if (V.email) d.email = V.email;
    d.hasMenu = { "@type": "Menu", name: "Carte de " + C.name, hasMenuSection: C.menu.map(function (c) {
      var items = []; c.groups.forEach(function (g) { g.items.forEach(function (i) {
        var m = { "@type": "MenuItem", name: i[0] }; if (i[2]) m.description = i[2];
        if (i[1] != null) m.offers = { "@type": "Offer", price: Number(i[1]).toFixed(2), priceCurrency: C.currency }; items.push(m); }); });
      return { "@type": "MenuSection", name: c.name, hasMenuItem: items }; }) };
    var s = document.createElement("script"); s.type = "application/ld+json"; s.textContent = JSON.stringify(d); document.head.appendChild(s);
    if (S.url) { var l = document.createElement("link"); l.rel = "canonical"; l.href = S.url; document.head.appendChild(l); }
  })();

  /* ---------- avis (défilement continu) ---------- */
  (function () {
    var R = C.reviews, car = $("#car"), vp = $("#rvp"), track = $("#rtrack"), mqR = window.matchMedia("(prefers-reduced-motion: reduce)");
    $("#avisSum").textContent = "Note Google Maps : " + R.rating + " sur 5 · " + R.count + " avis";
    var vis = true, x = 0, setW = 0, step = 380, paused = false, hov = false, foc = false, drag = false, tw = null, last = 0, raf = 0, SPEED = 34, sx = 0, x0 = 0, tm;
    function card(r, hidden) {
      var a = el("article", "rcard"), s = el("div", "stars"), mid = el("div", "mid"), p = el("p", "who");
      s.setAttribute("role", "img"); s.setAttribute("aria-label", r.stars + " étoiles sur 5"); s.textContent = "★★★★★".slice(0, r.stars);
      if (r.text) { var q = el("blockquote"); q.textContent = "« " + r.text + " »"; mid.appendChild(q); }
      else if (!r.sub) { var n = el("p", "muted"); n.textContent = "Avis sans commentaire"; mid.appendChild(n); }
      if (r.sub) { var u = el("ul", "sub"); [["Cuisine", r.sub.cuisine], ["Service", r.sub.service], ["Ambiance", r.sub.ambiance]].forEach(function (x) { var li = el("li"); li.textContent = x[0] + " " + x[1] + "/5"; u.appendChild(li); }); mid.appendChild(u); }
      if (r.meta) { var m = el("p", "meta"); m.textContent = r.meta; mid.appendChild(m); }
      p.textContent = r.name; a.append(s, mid, p);
      if (hidden) a.setAttribute("aria-hidden", "true"); return a;
    }
    function build() {
      cancelAnimationFrame(raf); track.textContent = ""; track.style.transform = ""; vp.scrollLeft = 0;
      var it = R.items; if (!it.length) return;
      it.forEach(function (r) { track.appendChild(card(r)); });
      step = track.firstChild.offsetWidth + parseFloat(getComputedStyle(track.firstChild).marginRight);
      if (mqR.matches) { car.classList.add("static"); return; }
      car.classList.remove("static");
      var n = Math.ceil((vp.clientWidth + 400) / track.scrollWidth), k;
      for (k = 1; k < n; k++) it.forEach(function (r) { track.appendChild(card(r, true)); });
      var len = track.children.length;
      for (k = 0; k < len; k++) track.appendChild(card(it[k % it.length], true));
      setW = track.children[len].offsetLeft - track.children[0].offsetLeft;
      last = performance.now(); if (vis) raf = requestAnimationFrame(tick);
    }
    function tick(t) {
      var dt = Math.min(0.05, (t - last) / 1000), dx; last = t;
      if (tw) { var p = Math.min(1, (t - tw.t0) / 450); x = tw.a + (tw.b - tw.a) * (1 - Math.pow(1 - p, 3)); if (p === 1) tw = null; }
      else if (!paused && !hov && !foc && !drag) x -= SPEED * dt;
      if (!tw) { while (x <= -setW) x += setW; while (x > 0) x -= setW; }
      dx = x; while (dx <= -setW) dx += setW; while (dx > 0) dx -= setW;
      track.style.transform = "translate3d(" + dx + "px,0,0)"; raf = requestAnimationFrame(tick);
    }
    function nav(d) { if (car.classList.contains("static")) { vp.scrollBy({ left: d * step }); return; } tw = { a: x, b: x - d * step, t0: performance.now() }; }
    $("#rPrev").onclick = function () { nav(-1); }; $("#rNext").onclick = function () { nav(1); };
    var pb = $("#rPause"); pb.onclick = function () { paused = !paused; pb.setAttribute("aria-pressed", paused); pb.textContent = paused ? "Lecture" : "Pause"; };
    vp.addEventListener("pointerenter", function (e) { if (e.pointerType === "mouse") hov = true; });
    vp.addEventListener("pointerleave", function () { hov = false; });
    car.addEventListener("focusin", function (e) { foc = e.target.matches(":focus-visible"); });
    car.addEventListener("focusout", function () { foc = false; });
    vp.addEventListener("pointerdown", function (e) { if (car.classList.contains("static")) return; drag = true; tw = null; sx = e.clientX; x0 = x; vp.setPointerCapture(e.pointerId); });
    vp.addEventListener("pointermove", function (e) { if (drag) x = x0 + e.clientX - sx; });
    ["pointerup", "pointercancel"].forEach(function (n) { vp.addEventListener(n, function () { drag = false; }); });
    addEventListener("resize", function () { clearTimeout(tm); tm = setTimeout(build, 200); });
    (mqR.addEventListener ? mqR.addEventListener("change", build) : mqR.addListener(build));
    build();
    if (window.IntersectionObserver) new IntersectionObserver(function (e) {
      vis = e[0].isIntersecting;
      if (vis && !raf && setW) { last = performance.now(); raf = requestAnimationFrame(tick); } else if (!vis) { cancelAnimationFrame(raf); raf = 0; }
    }).observe(car);
  })();

  /* ---------- héros piloté par le défilement (séquence d'images sur mobile, vidéo sur grand écran) ---------- */
  (function () {
    var H = C.hero, N = H.frames, FPS = H.fps, DUR = H.duration, HOLD = 0.88;
    var root = document.documentElement, hero = $("#hero"), pin = $(".pin"), v = $("#hv"), cv = $("#hseq"), ctx = cv.getContext("2d"), hdr = $("#hdr"), scrim = $("#scrim");
    var scenes = [].slice.call(document.querySelectorAll(".scene")), so = [], mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    var T = [[-1, 0, 2.3, 2.8], [3.1, 3.5, 6.2, 6.6], [6.9, 7.2, 7.5, 7.9], [9.4, 9.7, 99, 100]]; // secondes de la vidéo : fondu entrant/sortant
    var mode = "", failed = false, hTop = 0, dist = 1, ticking = false, dur = 0, want = 0, seeking = false, vInit = false;
    var sets = {}, S = null, K = "", drawn = -1, wantF = 0, solid = null, light = false, scrimO = -1, lastW = innerWidth, tm;
    var clamp = function (x) { return Math.max(0, Math.min(1, x)); };
    var ramp = function (t, a, b, c, d) { return Math.max(0, Math.min(1, (t - a) / (b - a), (d - t) / (d - c))); };
    var pad = function (n) { return ("00" + n).slice(-3); };

    function pickMode() { if (mq.matches || failed) return "static"; if (innerWidth > 900) return "video"; return innerWidth / innerHeight > 1.25 ? "seqL" : "seqP"; }
    function measure() { hTop = hero.offsetTop; dist = Math.max(1, hero.offsetHeight - pin.offsetHeight); }
    function applyMode() {
      var m = pickMode(); if (m === mode) return; mode = m; solid = null;
      root.classList.toggle("static", m === "static");
      v.hidden = m !== "video"; cv.hidden = m.indexOf("seq") !== 0;
      if (m === "static") { scenes.forEach(function (s) { s.style.opacity = ""; s.style.visibility = ""; s.removeAttribute("inert"); }); so = []; hdr.classList.remove("light"); light = false; }
      else if (m === "video") ensureVideo();
      else startSeq(m === "seqP" ? "p" : "l");
      measure(); update();
    }
    /* --- séquence d'images (mobile) --- */
    function startSeq(k) {
      K = k; cv.width = k === "p" ? 480 : 720; cv.height = k === "p" ? 1000 : 405; drawn = -1;
      var s = S = sets[k] || (sets[k] = { imgs: [], started: false });
      if (!s.started) {
        s.started = true; var order = [], seen = {}, q, active = 0;
        [12, 4, 1].forEach(function (st) { for (var i = 0; i < N; i += st) if (!seen[i]) { seen[i] = 1; order.push(i); } });
        q = order;
        (function pump() {
          while (active < 6 && q.length) (function (i) {
            var im = new Image(); active++; im.decoding = "async";
            im.onload = function () { s.imgs[i] = im; active--; if (S === s) render(); pump(); };
            im.onerror = function () { active--; if (i === 0 && !s.imgs[0]) { failed = true; applyMode(); } pump(); };
            im.src = "assets/frames/" + k + "/" + pad(i + 1) + ".webp";
          })(q.shift());
        })();
      }
      render();
    }
    function render() {
      if (!S) return; var f = wantF, im = null, i = f, d;
      for (d = 0; d < N; d++) { if (S.imgs[f - d]) { im = S.imgs[f - d]; i = f - d; break; } if (S.imgs[f + d]) { im = S.imgs[f + d]; i = f + d; break; } }
      if (im && i !== drawn) { ctx.drawImage(im, 0, 0); drawn = i; }
    }
    /* --- vidéo (grand écran) --- */
    function ensureVideo() {
      if (vInit) return; vInit = true;
      v.addEventListener("loadedmetadata", function () { dur = isFinite(v.duration) ? v.duration : 0; v.pause(); update(); });
      v.addEventListener("seeked", function () { seeking = false; seek(); });
      v.addEventListener("error", function () { failed = true; applyMode(); }, true);
      var s = document.createElement("source"); s.src = H.video; s.type = /\.webm$/.test(H.video) ? "video/webm" : "video/mp4"; v.appendChild(s); v.load();
      setTimeout(function () { if (!dur && v.readyState === 0 && mode === "video") { failed = true; applyMode(); } }, 12000);
    }
    function seek() { if (seeking || !dur || mode !== "video") return; if (Math.abs(v.currentTime - want) < 1 / 48) return; seeking = true; v.currentTime = want; }

    function update() {
      ticking = false; var y = window.scrollY, sol = mode === "static" || y >= hTop + dist - 2;
      if (sol !== solid) { solid = sol; hdr.classList.toggle("solid", sol); }
      if (mode === "static") return;
      var p = clamp((y - hTop) / dist), t = clamp(p / HOLD) * DUR, lt = t > 8.6 && t < 9.3 && !sol;
      if (lt !== light) { light = lt; hdr.classList.toggle("light", lt); }
      if (mode === "video") { want = Math.min(t, (dur || DUR) - 0.04); seek(); } else { wantF = Math.min(N - 1, Math.round(t * FPS)); render(); }
      scenes.forEach(function (s, i) {
        var o = Math.round(ramp(t, T[i][0], T[i][1], T[i][2], T[i][3]) * 50) / 50; if (o === so[i]) return; so[i] = o;
        s.style.opacity = o; s.style.visibility = o < 0.02 ? "hidden" : "visible"; if (o < 0.5) s.setAttribute("inert", ""); else s.removeAttribute("inert");
      });
      var w = Math.round((1 - clamp((t - 8.0) / 0.4) * clamp((9.5 - t) / 0.3)) * 50) / 50; // fondu blanc (~8,0 s à ~9,3 s) : on masque le voile sombre
      if (w !== scrimO) { scrimO = w; scrim.style.opacity = w; }
    }
    function req() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
    addEventListener("scroll", req, { passive: true });
    addEventListener("resize", function () { clearTimeout(tm); tm = setTimeout(function () { if (innerWidth !== lastW) { lastW = innerWidth; applyMode(); } measure(); req(); }, 150); }); // la hauteur seule (barre d'adresse mobile) est ignorée
    addEventListener("pageshow", function () { measure(); req(); });
    (mq.addEventListener ? mq.addEventListener("change", applyMode) : mq.addListener(applyMode));
    applyMode();
  })();
})();
