# New Restaurant : site statique
Fichiers : index.html, style.css, app.js, config.js, fonts.css, assets/ (aucune dépendance externe).
- **Aperçu local** : `python3 serve.py` (serveur avec support Range, nécessaire au défilement vidéo) dans ce dossier, puis http://localhost:8000
- **À modifier** : config.js (prix `null` = « [ajouter le prix] », adresse, horaires, téléphone, `directionsUrl`, `orderUrl`, `shopPhoto`, textes légaux). Les boutons Itinéraire/Commander restent désactivés tant que leur lien est vide.
- **Héros** : assets/hero-new-restaurant-kebab.mp4 (ré-encodé, images clés rapprochées pour un défilement fluide). Les minutages des textes sont dans `app.js` (tableau `T`, en secondes).
- **Mise en ligne (IONOS)** : envoyer le contenu du ZIP à la racine de l'hébergement.

- **Avis clients** : modifiez `reviews.items` dans config.js (nom, étoiles, texte). Avec « réduire les animations », le carrousel devient une rangée à faire défiler à la main.

## SEO et référencement local
Déjà en place : titre et description, H1/H2/H3 (le menu est présent dans la page pour tous les plats), alt descriptifs, noms d'images explicites, données structurées Schema.org (Restaurant + Menu, générées depuis config.js), robots.txt, sitemap.xml, .htaccess (compression, cache), polices et image d'accroche préchargées.
**À faire après la mise en ligne** :
1. Renseigner `site.url` dans config.js (avec le « / » final) ; remplacer VOTRE-DOMAINE dans sitemap.xml et robots.txt ; ajouter les balises og:url et og:image (voir le commentaire dans index.html).
2. Compléter le téléphone (`phone`, `phoneHref`), l'e-mail et les mentions légales dans config.js.
3. Google Search Console : ajouter le site, vérifier la propriété, envoyer sitemap.xml, demander l'indexation de la page d'accueil.
4. Google Business Profile : revendiquer/vérifier la fiche, y mettre exactement la même adresse, les mêmes horaires et le même téléphone que sur le site, la catégorie principale (restaurant turc), des photos, le menu et le lien vers le site.
5. Tester avec le test des résultats enrichis de Google et PageSpeed Insights ; garder les infos identiques partout (site, Google, Instagram).
Aucun classement n'est garanti : le référencement local prend du temps et dépend notamment de la fiche Google, des avis et de la concurrence.

- **Héros sur mobile** : séquences d'images dans assets/frames/ (p = portrait, l = paysage, 120 images à 12 i/s). Si vous changez la vidéo, régénérez-les avec ffmpeg (voir le README) et ajustez `hero` dans config.js.
